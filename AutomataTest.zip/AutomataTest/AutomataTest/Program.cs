﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace AutomataTest
{
    

    public struct student
    {
        char[] name;
        public int roll;
        public float marks;
    };


    interface A
    {

        void Hello();

    }



    interface B

    {

        void Hello();

    }



    class Test : A, B

    {
        //void B.Hello()
        //{
        //    Console.WriteLine("Hello to all-B");
        //}

        //void A.Hello()
        //{
        //    Console.WriteLine("Hello to all-A");
        //}

        public void Hello()
        {
            Console.WriteLine("Hello to all");
        }

        //void Hello()

        //{

        //    Console.WriteLine("Hello to all-B");

        //}

    }

    public class Singleton
    {
        private Singleton()
        {
        }

        private static Singleton instance;

        public static Singleton GetInstance()
        {
            if (instance == null)
            {
                instance = new Singleton();
                return instance;
            }
            else
                return instance;
        }
    }

    //public class Program
    //{

    //    public static void Main()

    //    {

    //        A Obj1 = new Test();

    //        Obj1.Hello();



    //        B Obj2 = new Test();

    //        Obj2.Hello();

    //    }


    public class Program
    {
        enum Days { Sat, Sun, Mon, Tue, Wed, Thu, Fri };

        public class Generic<T>
        {
            public T Field;
        }
        static void methodOne(int[] a)
        {
            int[] b = new int[5];

            a = b;

            Console.WriteLine(a.Length);

            Console.WriteLine(b.Length);
        }
        public class InterviewProgram
        {
            public void display(params int[] b)
            {
                foreach (int i in b)
                {
                    Console.WriteLine("ARRAY IS HAVING:{0}", i);
                }
            }
        }
        public abstract class class1 
        {
            public int x = 7;
            public string DoSomething()
            {
                return "Class1";
            }
        }

        public class class2 : class1
        {
            public int x = 79;
            public string DoSomething()
            {
                return "Class2";
            }
        }

        public class class3: class2
        {
            public new string DoSomething()
            {
                return "Class3";
            }
        }
        static int diagonalDifference(int[,] arr)
        {
            int i, j;
            int sumD1 = 0;
            int sumD2 = 0;
            for (i = 0; i < arr.GetLength(0); i++)
            {
                for (j = 0; j < arr.GetLength(0); j++)
                {
                    if (i == j)
                    {
                        sumD1 += arr[i, j];
                    }
                    if (i + j == arr.GetLength(0) - 1)
                    {
                        sumD2 += arr[i, j];
                    }
                }
            }
            return Math.Abs(sumD1 - sumD2);
        }
        static void Main(string[] args)
        {
            //class2 c2 = new class2();
            //Console.WriteLine(c2.x);

            //string greet = "Hello";
            //string copy = greet;
            //greet = "World";
            //var test = Object.ReferenceEquals(greet, copy);
            //Console.WriteLine($"{copy} {test}");

            A Obj1 = new Test();
            Obj1.Hello();
            B Obj2 = new Test();
            Obj2.Hello();
            Test a = new Test();
            a.Hello();


            //Dictionary<class2, class3> dict = new Dictionary<class2, class3>();
            //class2 a1 = new class2();
            //class3 a2 = new class2();
            //dict.Add(a1, null);
            ////dict.Add(null, a2);
            //class3 a = new class2();

            //int[,] arr = { { 11 ,2, 4},
            //    { 4,5,6},
            //    { 10,8,-12} };
            //int result = diagonalDifference(arr);


            //Console.WriteLine(a.DoSomething()); 
            //foreach (var obj in Enum.GetValues(typeof(Days)))
            //{
            //    Console.WriteLine(obj);
            //}
            //Enum.Parse(typeof(Days),"Wed");
            //Array arr = Enum.GetValues(typeof(Days));

            //List<string> lstDays = new List<string>(arr.Length);
            //for (int i = 0; i < arr.Length; i++)
            //{
            //    lstDays.Add(arr.GetValue(i).ToString());
            //}
            //int[] firstArray = { 9, 2, 3, 4 };
            //    int[] secondArray = { 5, 6, 7, 0 };
            //    int[] combined = firstArray.Concat(secondArray).ToArray();
            //    Array.Sort(combined);
            //string str = "helllo";
            //int i, j;
            //List<string> strArr = new List<string>();
            //for (i = 1; i < str.Length; i++)
            //{
            //    for (j = 0; j <= str.Length - i; j++)
            //    {
            //        string subStr = str.Substring(j, i);
            //        strArr.Add(subStr);
            //        Console.WriteLine(subStr);
            //    }
            //}

            //Stack<char> stack = new Stack<char>();
            //string Test = "eye";
            //string check = string.Empty;
            //foreach (char ch in Test)
            //{
            //    stack.Push(ch);
            //}
            //while (stack.Count!=0)
            //{
            //    check += stack.Pop();
            //}
            //Console.WriteLine(check);
            ////stack.Push(12);
            ////stack.Push("e");
            ////stack.Push("abc");
            ////Console.WriteLine(stack.Peek());
            ////Console.WriteLine(stack.Pop());
            //foreach (object obj in stack)
            //{
            //    Console.WriteLine(obj);
            //}
            //int val=int.Parse(Console.ReadLine());
            //Dictionary<int,int> result = new Dictionary<int,int>();
            //result.Add(1, 2);
            //result.Add(2, 2);
            //result.Add(3, 7);
            //result.Add(4, 1);
            //int max = 0;
            //int MaxVal;
            //foreach (KeyValuePair<int, int> pair in result)
            //{
            //    MaxVal = Math.Max(max,pair.Value);
            //    max = MaxVal;
            //}
            //int val2 = 0;
            //result.TryGetValue(max, out val2);
            //string str = "12  3";
            //string newStr=Regex.Replace(str,@"\s","%20");
            //int count=newStr.Length;
            //int sum = 0;
            //int[] deno = { 1,2,5,10,20,100,200,2000};
            //int len = deno.Length;
            //int i;
            //int Value=val;
            //for (i=len-1;i>=0;i--)
            //{
            //    while (Value >= deno[i]) 
            //    {
            //        if (Value - deno[i] >= 0)
            //        {
            //            if (result.ContainsKey(deno[i]))
            //            {
            //                result[deno[i]]++;
            //            }
            //            else
            //                result.Add(deno[i],1);
            //            Value -= deno[i];
            //            sum += deno[i];
            //            if (sum==val)
            //            {
            //                foreach (KeyValuePair<int, int> pair in result)
            //                {
            //                    Console.WriteLine(pair.Key + " : " + pair.Value);
            //                }
            //            }
            //        }
            //    }
            //}

            //int i,j;
            //int[] cells = {1,0,0,0,0,1,0,0 };
            //int days = int.Parse(Console.ReadLine());
            //int row = cells.Length;
            //int[] u = new int[10];
            //for (i=0;i<days;i++)
            //{
            //    Array.Copy(cells,0,u,1,8);
            //    //for (i=0;i<=row;i++)
            //    //{
            //    //    if (i==0||i==row)
            //    //    {
            //    //        u[i]= 0;
            //    //    }
            //    //    else
            //    //    {
            //    //        u[i] = cells[i];
            //    //    }

            //    //}

            //    for (j=1;j<row;j++)
            //    {
            //        if (u[j - 1] == u[j + 1])
            //        {
            //            u[j] = 0;
            //        }
            //        else
            //            u[j] = 1;
            //    }

            //}
            //for (i = 0; i < row; i++)
            //{
            //    Console.Write(u[i]);
            //}
        }

        public static long factorial(int num)
        {
            int n = 1;
            long result = 1;
            while (n <= num)
            {
                result = result * n;
                n++;
            }
            return result;
        }

        static void reverseSentence()
        {
            char c;
            c = (char)Console.Read();

            if (c != '\n')
            {
                reverseSentence();
                Console.Write(c);
            }
        }


        public static int fact2(int d1)
        {
            if (d1 >= 1)
            {
                return (d1 * fact2(d1 - 1));
            }
            return 1;
        }

        public static int power(int d1, int d2)
        {
            if (d2 != 0)
            {
                return (d1 * power(d1, d2 - 1));
            }
            return 1;
        }


        public static long fact(int num)
        {
            int i;
            long fact = 1;
            int number;
            number = num;
            for (i = 1; i <= number; i++)
            {
                fact = fact * i;
            }
            return fact;
        }



        //int i, j,k;
        //int rows;
        //int space;
        //int number;
        //Console.WriteLine("Enter number of rows");
        //rows = int.Parse(Console.ReadLine());

        //for (i=1;i<=rows;i++)
        //{
        //    for (space=1;space<=rows-i;space++)
        //    {
        //        Console.Write("   ");
        //    }
        //    number = 1;
        //    for (j=1;j<2*i;j++)
        //    {
        //        Console.Write(" "+number+" ");
        //        number++;
        //    }
        //    //number = i;
        //    //for (j=1;j<=i;j++)
        //    //{
        //    //    Console.Write(number-1);
        //    //    number--;
        //    //}
        //    //number++;
        //    //for (k=1;k<=i-1;k++)
        //    //{
        //    //    Console.Write(number);
        //    //    number++;
        //    //}
        //    Console.Write("\n");
        //}
        ////int newRow = rows - 1;
        ////for (i = newRow; i >= 1; i--)
        ////{
        ////    for (space = 0; space <= newRow - i; space++)
        ////    {
        ////        Console.Write(" ");
        ////    }
        ////    //for (j = 1; j >=1; j--)
        ////    //{
        ////    //    Console.Write("*");
        ////    //    //if (i!=j)
        ////    //    //{
        ////    //    //    Console.Write("*");
        ////    //    //}
        ////    //    //number++;
        ////    //}
        ////    j = 1;
        ////    while (j != 2 * i)
        ////    {
        ////        Console.Write("*");
        ////        j++;
        ////    }
        ////    Console.Write("\n");
        ////}
        //}
    }
}
