﻿using System;
using System.Collections.Generic;

namespace AutomataTest2
{
    class employee
    {
        public string name;
        public int age;
        public employee(employee emp)   // declaring Copy constructor.
        {
            name = emp.name;
            age = emp.age;
        }
        public employee(string name, int age)  // Instance constructor.
        {
            this.name = name;
            this.age = age;
        }
        public string Details     // Get deatils of employee
        {
            get
            {
                return " The age of " + name + " is " + age.ToString();
            }
        }
    }

        class Program
        {

            static void Main(string[] args)
            {
                employee emp1 = new employee("Vithal", 23);  // Create a new employee object.
                employee emp2 = new employee(emp1);          // here is emp1 details is copied to emp2.
            employee emp3 = emp1;
            emp3.name = "New Name";
            Console.WriteLine(emp2.Details);
                Console.ReadLine();

                //string str = ")(97766(878)((77))";
                //int errorAt;
                //bool ans = AreParenthesesBalanced(str,out errorAt);
                //Console.WriteLine(ans);
                //List<int> iList = new List<int>();
                //iList.Add(2);
                //iList.Add(3);
                //iList.Add(6);
                //iList.Add(4);
                //iList.Add(5);


                //var x = findCode(5, -3, iList.ToArray());
                //foreach (int i in x)
                //{
                //    Console.Write(i + " ");
                //}
                //Console.ReadKey();
            }

            public static bool AreParenthesesBalanced(string str, out int errorAt)
            {
                const char LeftParenthesis = '(';
                const char RightParenthesis = ')';
                var items = new Stack<int>(str.Length);
                errorAt = -1;
                for (int i = 0; i < str.Length; i++)
                {
                    char c = str[i];
                    if (c == LeftParenthesis)
                        items.Push(i);
                    else if (c == RightParenthesis)
                    {
                        if (items.Count == 0)
                        {
                            errorAt = i + 1;
                            return false;
                        }
                        items.Pop();
                    }
                }
                if (items.Count > 0)
                {
                    errorAt = items.Peek() + 1;
                    return false;
                }
                return true;
            }

            public static List<int> findCode(int size, int key, int[] message)
            {
                int[] temp = new int[size];
                List<int> code = new List<int>();

                for (int i = 0; i < size; i++)
                {
                    if (key > 0)
                    {
                        for (int j = 1; j <= key; j++)
                        {
                            if (i + j < size)
                            {
                                temp[i] += message[j + i];
                            }
                            else
                            {
                                temp[i] += message[Math.Abs((i + j) - size)];
                            }
                        }
                    }

                    else
                    {
                        for (int j = Math.Abs(key - 1); j > 1; j--)
                        {
                            if (i + j < size)
                            {
                                temp[i] += message[j + i];
                            }
                            else
                            {
                                temp[i] += message[Math.Abs((i + j) - size)];
                            }
                        }
                    }
                }


                foreach (var k in temp)
                {
                    code.Add(k);
                }

                return code;
            }
        }
    }

