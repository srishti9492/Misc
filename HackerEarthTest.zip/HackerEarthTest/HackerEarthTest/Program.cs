﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HackerEarthTest
{
    class Program
    {
        static void Main(string[] args)
        {
            string line = string.Empty;
            string[] ip = new string[10];
            int i = 0;
            bool result = true;
            Dictionary<string, int> dict = GetDictionary();
            while (!String.IsNullOrWhiteSpace(line = Console.ReadLine()))
            {
                ip[i] = line;
                i++;
            }

            foreach (string ip1 in ip)
            {
                if (!String.IsNullOrEmpty(ip1))
                {
                    string[] ip2 = new string[10];
                    ip2 = ip1.Split();
                    int total = 0;
                    int temp = 0;
                    int check=0 ;
                    foreach (string ip3 in ip2)
                    {
                        if (dict.ContainsKey(ip3))
                        {
                            int num = dict[ip3];
                            if (num == 1000)
                            {
                                total += temp * num;
                                temp = 0;
                                check++;
                            }
                            else if (num == 100)
                            {
                                temp = temp * num;
                                check++;
                            }
                            else
                            {
                                temp = temp + num;
                            }
                        }
                        else
                        {
                            result = false;
                            break;
                        }
                        result = true;
                    }
                    if (result&&check!=0)
                    {
                        total = total + temp;
                        Console.WriteLine(total);
                        Console.WriteLine(check);
                    }
                    else
                        Console.WriteLine("Cannot convert");
                }
            }
        
        //string line = string.Empty;
        //string[] ip = new string[10];
        //int i = 0;
        ////int key = int.Parse(Console.ReadLine());
        //while (!String.IsNullOrWhiteSpace(line = Console.ReadLine()))
        //{
        //    ip[i] = line;
        //    i++;
        //}

        //int j;
        //foreach (string ip1 in ip)
        //{
        //    if (!String.IsNullOrEmpty(ip1)) {
        //        string[] ip2 = ip1.Split();
        //        for (j = ip2.Length - 1; j >= 0; j--)
        //        {
        //            if(!String.IsNullOrWhiteSpace(ip2[j]))
        //                Console.Write(ip2[j] + " ");
        //        }
        //        Console.Write("\n");
        //    }
        //}


        //foreach (string ip1 in ip)
        //{
        //    if (!String.IsNullOrEmpty(ip1))
        //    {
        //        string[] ip2 = new string[10];
        //        ip2 = ip1.Split();
        //        foreach (string ip3 in ip2)
        //        {
        //            foreach (char ch in ip3)
        //            {
        //                if (ch >= 65 && ch <= 90 || ch >= 97 && ch <= 122)
        //                {
        //                    int val = (int)ch + key;
        //                    if (val >= 65 && val <= 90 || val >= 97 && val <= 122)
        //                    {
        //                        Console.Write((char)val);
        //                    }
        //                    else
        //                    {
        //                        key = key % 26;
        //                        val = (int)ch + key;
        //                        Console.Write((char)val);
        //                    }
        //                }
        //                else
        //                    Console.Write(ch);
        //            }
        //            Console.Write(" ");
        //        }
        //        Console.Write("\n");
        //    }
        //}

        //foreach (int ip1 in ip)
        //{
        //    int num = ip1;
        //    if (num != 0)
        //    {
        //        while (num != 0)
        //        {
        //            if (num / 1000 != 0)
        //            {
        //                int n = num / 1000;
        //                while (n != 0)
        //                {
        //                    if (n / 10 != 0)
        //                    {
        //                        int n1 = n / 10;
        //                        n1 = n1 * 10;
        //                        getKeyValue(n1);
        //                        n = n % 10;
        //                    }
        //                    else
        //                    {
        //                        getKeyValue(n);
        //                        Console.Write("thousand ");
        //                        n = n / 10;
        //                    }
        //                }
        //                num = num % 1000;
        //            }
        //            else if (num / 100 != 0)
        //            {
        //                int n = num / 100;
        //                getKeyValue(n);
        //                Console.Write("hundred ");
        //                num = num % 100;
        //            }
        //            else
        //            {
        //                if (num / 10 != 0)
        //                {
        //                    int n = num / 10;
        //                    n = n * 10;
        //                    getKeyValue(n);
        //                    num = num % 10;
        //                }
        //                else
        //                {
        //                    getKeyValue(num);
        //                    num = num / 10;
        //                }
        //            }
        //        }
        //        Console.Write("\n");
        //    }
        //}
    }

        private static void getKeyValue(int n1)
        {
            Dictionary<string, int> dict = GetDictionary();
            if (dict.ContainsValue(n1))
            {
                var myKey = dict.FirstOrDefault(x => x.Value == n1).Key;
                Console.Write(myKey + " ");
            }
        }

        private static Dictionary<string, int> GetDictionary()
        {
            Dictionary<string, int> dict = new Dictionary<string, int>();
            dict.Add("zero", 0);
            dict.Add("one", 1);
            dict.Add("two", 2);
            dict.Add("three", 3);
            dict.Add("four", 4);
            dict.Add("five", 5);
            dict.Add("six", 6);
            dict.Add("seven", 7);
            dict.Add("eight", 8);
            dict.Add("nine", 9);
            dict.Add("ten", 10);
            dict.Add("eleven", 11);
            dict.Add("twelve", 12);
            dict.Add("thirteen", 13);
            dict.Add("fourteen", 14);
            dict.Add("fifteen", 15);
            dict.Add("sixteen", 16);
            dict.Add("seventeen", 17);
            dict.Add("eighteen", 18);
            dict.Add("nineteen", 19);
            dict.Add("twenty", 20);
            dict.Add("thirty", 30);
            dict.Add("fourty", 40);
            dict.Add("fifty", 50);
            dict.Add("sixty", 60);
            dict.Add("seventy", 70);
            dict.Add("eighty", 80);
            dict.Add("ninety", 90);
            dict.Add("hundred", 100);
            dict.Add("thousand", 1000);
            return dict;

        }
            //int result;
            //int limit = int.Parse(Console.ReadLine());
            //List<int> temp = new List<int>();
            //int i = 0;
            //while (i!=limit)
            //{
            //    result=doWork(temp);
            //    temp.Add(result);
            //    i++;
            //}
            //foreach (int j in temp)
            //{
            //    Console.WriteLine(j);
            //}


            


        //int key = int.Parse(Console.ReadLine());
        //string[] s = new string [key];
        //string[] o = new string[key];
        //int i = 0;
        //int j,k,l;

            //string line = String.Empty;
            //while (!String.IsNullOrWhiteSpace(line = Console.ReadLine()))
            //{
            //    s[i] = line;
            //    i++;
            //}
            //for (j= 0;j < s.Length;j++)
            //{
            //    if (!String.IsNullOrEmpty(s[j])) {
            //        string[] ip2 = s[j].Split();
            //        for (k=0;k<ip2.Length;k++)
            //        {
            //            foreach (char ch in ip2[k])
            //            {
            //                if (ch >= 65 && ch <= 90 || ch >= 97 && ch <= 122)
            //                {
            //                    int total = (int)ch + key;
            //                    if (total >= 65 && total <= 90 || total >= 97 && total <= 122)
            //                    {
            //                        Console.Write((char)total);
            //                    }
            //                    else
            //                    {
            //                        int rem = key % 26;
            //                        total= (int)ch + rem;
            //                        Console.WriteLine((char)total);
            //                    }
            //                }
            //                else
            //                    Console.Write(ch);
            //            }
            //            Console.Write(" ");
            //        }
            //int temp=0;
            //int total=0;
            //foreach (string ip3 in ip2)
            //{
            //    int n;
            //    if (dict.ContainsKey(ip3))
            //    {
            //        n = dict[ip3];
            //        if (n >= 1000)
            //        {
            //            total += (temp * n);
            //            temp = 0;
            //        }
            //        else if (n >=100)
            //        {
            //            temp *= n;
            //        }
            //        else 
            //        {
            //            temp += n;
            //        }
            //    }
            //    else
            //        Console.Write("Cannot convert");
            //}
            //Console.WriteLine(total+ temp);
            //}
            //}
            //foreach (string str in s)
            //{
            //    inner+=str.
            //}
            //foreach (string ip in s)
            //{

            //    foreach (string ch in ip)
            //    {
            //        if (dict.ContainsKey(ch))
            //        {

            //        }
            //        else
            //            Console.WriteLine("Cannot convert");
            //    }
            //}
            //}


        private static int doWork(List<int> input)
        {
            int result = 1;
            if (input.Count == 0)
            {
                return 1;
            }
            else if (input.Count == 1)
            {
                return 2;
            }
            else
            {

                foreach (int i in input)
                {
                    result *= i;
                }
            }
            return result;
        }
    }
}
