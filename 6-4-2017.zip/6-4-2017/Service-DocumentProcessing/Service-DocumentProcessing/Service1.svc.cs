﻿using DocumentProcessing.Controller;
using DocumentProcessing.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Text;

namespace Service_DocumentProcessing
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class Service1 : IService1
    {
        public List<Metadata> GetMetaData()
        {
            List<Metadata> listDocumentData = new List<Metadata>();
            try
            {
                MetadataController metadataController = new MetadataController();
                listDocumentData = metadataController.GetAllMetadataDetails();
            }
            catch (Exception ex)
            {
                listDocumentData = new List<Metadata>();

            }
            return listDocumentData;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<DocumentTemplate> GetDocTemplate()
        {
            List<DocumentTemplate> listDocumentData = new List<DocumentTemplate>();
            try
            {
                DocumentTemplateController documentTemplateController = new DocumentTemplateController();
                listDocumentData = documentTemplateController.GetDocTemplateDetails();
            }
            catch (Exception ex)
            {
                listDocumentData = new List<DocumentTemplate>();

            }
            return listDocumentData;
        }//GetDocTemplate

        /// <summary>
        /// 
        /// </summary>
        /// <param name="documentTemplate"></param>
        public void AddDocTemplate(DocumentTemplate documentTemplate)
        {
            List<DocumentTemplate> listDocumentData = new List<DocumentTemplate>();
            try
            {
                DocumentTemplateController documentTemplateController = new DocumentTemplateController();
                documentTemplateController.StoreDocTemplateDetails(documentTemplate);
            }
            catch (Exception ex)
            {
                listDocumentData = new List<DocumentTemplate>();
            }
        }//AddDocTemplate

        /// <summary>
        /// 
        /// </summary>
        /// <param name="documentTemplate"></param>
        public void EditDocTemplate(DocumentTemplate documentTemplate)
        {
            List<DocumentTemplate> listDocumentData = new List<DocumentTemplate>();
            try
            {
                DocumentTemplateController documentTemplateController = new DocumentTemplateController();
                documentTemplateController.UpdateDocTemplateDetails(documentTemplate);
            }
            catch (Exception ex)
            {
                listDocumentData = new List<DocumentTemplate>();
            }
        }//EditDocTemplate

        /// <summary>
        /// 
        /// </summary>
        /// <param name="documentTemplate"></param>
        public void DeleteDocTemplate(DocumentTemplate documentTemplate)
        {
            List<DocumentTemplate> listDocumentData = new List<DocumentTemplate>();
            try
            {
                DocumentTemplateController documentTemplateController = new DocumentTemplateController();
                documentTemplateController.DeleteDocTemplateDetails(documentTemplate);
            }
            catch (Exception ex)
            {
                listDocumentData = new List<DocumentTemplate>();
            }
        }//DeleteDocTemplate
/****************************************************************************************************************/
        /// <summary>
        /// 
        /// </summary>
        /// <param name="mailSearch"></param>
        public void AddMailSearch(MailSearch mailSearch)
        {
            List<MailSearch> listDocumentData = new List<MailSearch>();
            try
            {
                MailSearchController mailSearchController = new MailSearchController();
                mailSearchController.AddMailSearchDetails(mailSearch);
            }
            catch (Exception ex)
            {
                listDocumentData = new List<MailSearch>();
            }
        }//AddMailSearch

        public void DeleteMailSearch(MailSearch mailSearch)
        {
            List<MailSearch> listDocumentData = new List<MailSearch>();
            try
            {
                MailSearchController mailSearchController = new MailSearchController();
                mailSearchController.DeleteMailSearchDetails(mailSearch);
            }
            catch (Exception ex)
            {
                listDocumentData = new List<MailSearch>();
            }
        }//DeleteMailSearch

        /*****************************************************************************************/

        public List<MetadataTypeMaster> GetNewMetadata()
        {
            List<MetadataTypeMaster> listnewMetadataType = new List<MetadataTypeMaster>();
            List<Metadata> listnewmetadata = new List<Metadata>();
            List<MetadataTypeMaster> resultList = new List<MetadataTypeMaster>();
            try
            {
                MetadataController metadataController = new MetadataController();
                listnewmetadata = metadataController.GetAllMetadataDetails();
                listnewMetadataType = metadataController.GetAllMetadatatypemasterDetails();
                var resultSet = listnewMetadataType.Intersect<MetadataTypeMaster>(listnewMetadataType);

                //Please return listnewMetadataType which is filtered after your logic (MetadataTypeMaster)

                foreach (MetadataTypeMaster item in listnewMetadataType)
                {
                    if (!listnewmetadata.Any(x => x.MetadataTypeId == item.MetadataTypeId))
                    {
                        // this code is executed on each item in firstList but not in secondList
                        resultList.Add(item);
                    }
                }
            }
            catch (Exception)
            {

                resultList = new List<MetadataTypeMaster>();
            }
            return resultList;
        }
        public void AddMetadata(Metadata metadata)
        {
            List<Metadata> listDocumentData = new List<Metadata>();
            try
            {
                MetadataController metadataController = new MetadataController();
                metadataController.StoreMetadataDetails(metadata);
            }
            catch (Exception ex)
            {
                listDocumentData = new List<Metadata>();

            }

        }

        public void DeleteMetadata(Metadata metadata)
        {
            List<Metadata> listDocumentData = new List<Metadata>();
            try
            {
                MetadataController metadataController = new MetadataController();
                metadataController.DeleteMetadataDetails(metadata);
            }
            catch (Exception ex)
            {
                listDocumentData = new List<Metadata>();

            }
        }

        public void EditMetaData(Metadata metadata)
        {
            List<Metadata> listDocumentData = new List<Metadata>();
            try
            {
                MetadataController metadataController = new MetadataController();
                metadataController.UpdateMetadataDetails(metadata);
            }
            catch (Exception ex)
            {
                listDocumentData = new List<Metadata>();

            }

        }

        public List<MetadataTypeMaster> GetAllMetadataTypes()
        {
            List<MetadataTypeMaster> listmetadatatypemaster = new List<MetadataTypeMaster>();
            try
            {
                MetadataController metadataController = new MetadataController();
                listmetadatatypemaster = metadataController.GetAllMetadatatypemasterDetails();
            }
            catch (Exception ex)
            {

                listmetadatatypemaster = new List<MetadataTypeMaster>();
            }
            return listmetadatatypemaster;
        }

        public void AddMetadataType(MetadataTypeMaster metadatatype)
        {
            List<MetadataTypeMaster> listDocumentData = new List<MetadataTypeMaster>();
            try
            {
                MetadataController metadataController = new MetadataController();
                metadataController.StoreMetadataTypeDetails(metadatatype);
            }
            catch (Exception ex)
            {
                listDocumentData = new List<MetadataTypeMaster>();

            }
        }

        public void EditMetaDataType(MetadataTypeMaster metadatatype)
        {
            List<MetadataTypeMaster> listDocumentData = new List<MetadataTypeMaster>();
            try
            {
                MetadataController metadataController = new MetadataController();
                metadataController.UpdateMetadataTypeDetails(metadatatype);
            }
            catch (Exception ex)
            {
                listDocumentData = new List<MetadataTypeMaster>();

            }
        }

        public void DeleteMetadatatype(MetadataTypeMaster metadatatype)
        {
            List<MetadataTypeMaster> listDocumentData = new List<MetadataTypeMaster>();
            try
            {
                MetadataController metadataController = new MetadataController();
                metadataController.DeleteMetadataTypeDetails(metadatatype);
            }
            catch (Exception ex)
            {
                listDocumentData = new List<MetadataTypeMaster>();

            }
        }

        public List<MailCriteria> GetMailSearchCriteria()
        {
            List<MailCriteria> listSearchCriteria = new List<MailCriteria>();
            try
            {
                MailCriteriaController mailCriteriaController = new MailCriteriaController();
                listSearchCriteria = mailCriteriaController.GetMailSearchCriteriaDetails();
            }
            catch (Exception ex)
            {
                listSearchCriteria = new List<MailCriteria>();
            }
            return listSearchCriteria;
        }

        public void AddMailSearchCriteria(MailCriteria mailSearch)
        {
            List<MailCriteria> listMailSearchData = new List<MailCriteria>();
            try
            {
                MailCriteriaController mailCriteriaController = new MailCriteriaController();
                mailCriteriaController.StoreMailSearchCriteriaDetails(mailSearch);
            }
            catch (Exception ex)
            {
                listMailSearchData = new List<MailCriteria>();

            }
        }

        public void EditMailSearchCriteria(MailCriteria mailSearch)
        {
            List<MailCriteria> listMailSearchData = new List<MailCriteria>();
            try
            {
                MailCriteriaController mailCriteriaController = new MailCriteriaController();
                mailCriteriaController.UpdateMailSearchCriteriaDetails(mailSearch);
            }
            catch (Exception ex)
            {
                listMailSearchData = new List<MailCriteria>();

            }
        }

        public void DeleteMailSearchCriteria(MailCriteria mailSearch)
        {
            List<MailCriteria> listMailSearchData = new List<MailCriteria>();
            try
            {
                MailCriteriaController mailCriteriaController = new MailCriteriaController();
                mailCriteriaController.DeleteMailSearchCriteriaDetails(mailSearch);
            }
            catch (Exception ex)
            {
                listMailSearchData = new List<MailCriteria>();

            }


        }

        public List<MailSearch> GetMailSearchDetails()
        {
            List<MailSearch> listMailSearch = new List<MailSearch>();
            try
            {
                MailSearchController mailSearchController = new MailSearchController();
                listMailSearch = mailSearchController.GetMailSearch();
            }
            catch (Exception ex)
            {

                listMailSearch = new List<MailSearch>();
            }
            return listMailSearch;
        }

        /// <summary>
        /// To add new attributes to the attributes table
        /// </summary>
        /// <param name="documentAttributes"></param>
        public void AddAttributes(DocumentAttributes documentAttributes)
        {
            List<DocumentAttributes> listDocumentAttributes = new List<DocumentAttributes>();
            try
            {
                DocumentAttributeController documentAttributeController = new DocumentAttributeController();
                documentAttributeController.StoreAttributeDetails(documentAttributes);
            }
            catch (Exception ex)
            {
                listDocumentAttributes = new List<DocumentAttributes>();
            }
        }

        /// <summary>
        /// To populate attributes list based on metadata type dropdown selection
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public List<DocumentAttributes> GetAttributes(string id)
        {
            List<DocumentAttributes> listAttributesData = new List<DocumentAttributes>();
            try
            {
                DocumentAttributeController documentAttributeController = new DocumentAttributeController();
                listAttributesData = documentAttributeController.GetAttributesById(int.Parse(id));
            }
            catch (Exception ex)
            {
                listAttributesData = new List<DocumentAttributes>();

            }
            return listAttributesData;
        }

        /// <summary>
        /// To update attribute values
        /// </summary>
        /// <param name="documentAttributes"></param>
        /// <returns></returns>
        public void EditAttributes(DocumentAttributes documentAttributes)
        {
            List<DocumentAttributes> listDocumentAttributes = new List<DocumentAttributes>();
            try
            {
                DocumentAttributeController documentAttributeController = new DocumentAttributeController();
                documentAttributeController.UpdateAttributeDetails(documentAttributes);
            }
            catch (Exception ex)
            {
                listDocumentAttributes = new List<DocumentAttributes>();
            }
        }

        /// <summary>
        /// To delete attribute values
        /// </summary>
        /// <param name="documentAttributes"></param>
        /// <returns></returns>
        public void DeleteAttributes(DocumentAttributes documentAttributes)
        {
            List<DocumentAttributes> listDocumentAttributes = new List<DocumentAttributes>();
            try
            {
                DocumentAttributeController documentAttributeController = new DocumentAttributeController();
                documentAttributeController.DeleteAttributeDetails(documentAttributes);
            }
            catch (Exception ex)
            {
                listDocumentAttributes = new List<DocumentAttributes>();
            }
        }


    }
}
