﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using DocumentProcessing.View;

namespace Service_DocumentProcessing
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.

    [ServiceContract]

    public interface IService1
    {

        [OperationContract]
        [WebGet(UriTemplate = "/GetMetaData", ResponseFormat = WebMessageFormat.Json)]
        List<Metadata> GetMetaData();
                        
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/EditMetaData/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void EditMetaData(Metadata metadata);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/AddMetadata/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void AddMetadata(Metadata metadata);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/DeleteMetadata/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void DeleteMetadata(Metadata metadata);

        [OperationContract]
        [WebGet(UriTemplate = "/GetAllMetadataTypes", ResponseFormat = WebMessageFormat.Json)]
        List<MetadataTypeMaster> GetAllMetadataTypes();

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/EditMetaDataType/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void EditMetaDataType(MetadataTypeMaster metadatatype);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/AddMetadataType/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void AddMetadataType(MetadataTypeMaster metadatatype);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/DeleteMetadatatype/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void DeleteMetadatatype(MetadataTypeMaster metadatatype);

        [OperationContract]
        [WebGet(UriTemplate = "/GetNewMetadata", ResponseFormat = WebMessageFormat.Json)]
        List<MetadataTypeMaster> GetNewMetadata();

        [OperationContract]
        [WebGet(UriTemplate = "/GetMailSearchCriteria", ResponseFormat = WebMessageFormat.Json)]
        List<MailCriteria> GetMailSearchCriteria();

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/EditMailSearchCriteria/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void EditMailSearchCriteria(MailCriteria mailCriteria);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/AddMailSearchCriteria/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void AddMailSearchCriteria(MailCriteria mailCriteria);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/DeleteMailSearchCriteria", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void DeleteMailSearchCriteria(MailCriteria mailCriteria);

        [OperationContract]
        [WebGet(UriTemplate = "/GetAllMailSearch", ResponseFormat = WebMessageFormat.Json)]
        List<MailSearch> GetMailSearchDetails();

        [OperationContract]
        [WebGet(UriTemplate = "/GetAttributes/{id}", ResponseFormat = WebMessageFormat.Json)]
        List<DocumentAttributes> GetAttributes(string id);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/EditAttributes", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void EditAttributes(DocumentAttributes documentAttributes);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/AddAttributes", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void AddAttributes(DocumentAttributes documentAttributes);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/DeleteAttributes", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void DeleteAttributes(DocumentAttributes documentAttributes);

        [OperationContract]
        [WebGet(UriTemplate = "/GetDocTemplate", ResponseFormat = WebMessageFormat.Json)]
        List<DocumentTemplate> GetDocTemplate();

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/EditDocTemplate", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void EditDocTemplate(DocumentTemplate documentTemplate);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/AddDocTemplate", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void AddDocTemplate(DocumentTemplate documentTemplate);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/DeleteDocTemplate", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void DeleteDocTemplate(DocumentTemplate documentTemplate);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/AddMailSearch/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void AddMailSearch(MailSearch mailSearch);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/DeleteMailSearch/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void DeleteMailSearch(MailSearch mailSearch);

    }

}



