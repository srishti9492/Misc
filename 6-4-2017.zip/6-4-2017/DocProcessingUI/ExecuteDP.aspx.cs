﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class ExecuteDP : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        DocumentProcessing.DocumentProcess.DocumentProcessing obj = new DocumentProcessing.DocumentProcess.DocumentProcessing();
        obj.StartDocumentProcessing();
        Response.Write("<script>alert('The Process is successfully Completed!');</script>");
        //Response.Write("Process completed");


    }
    
}