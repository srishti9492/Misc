﻿jQuery(document).ready(function () {
    jQuery("#dllTable2").hide();
    jQuery("#dllTable2").append("<option value=-1> --Select-- </option>");
    PopulateMetaTypeDropDown();
    jQuery("#dllTable2").on('change', function () { DestroyGrid(); GetAttributesByMetaTypeId(); });
    jQuery(".DocumentProcessing").on('change', function () {
        var selectedValue = jQuery(".DocumentProcessing").val();
        //switch case to select specific table
        switch (selectedValue) {
            case "1": DestroyGrid(); GetAttributesById(); break;
            case "2": DestroyGrid(); GetMetadata(); break;
            case "3": DestroyGrid(); GetMetadataType(); break;
            case "4": DestroyGrid(); GetMailSearch(); break;
            case "5": DestroyGrid(); GetMailSearchCriteria(); break;
            case "6": DestroyGrid(); GetDocTemplate(); break;
            default: DestroyGrid();
        }
    })
});
//Function to destroy previous grid before loading new grid
function DestroyGrid() {
    $('#contentPageMainPage').empty();
    $('#tableJqGrid').remove();
    var table = document.createElement('table');

    table.id = 'tableJqGrid';
    var pagerDiv = document.createElement('div');
    pagerDiv.id = 'pager';
    jQuery("#contentPageMainPage").append(table);
    jQuery("#contentPageMainPage").append(pagerDiv);
}

function GetDocTemplate() {
    jQuery("#dllTable2").hide();
    jQuery("#tableJqGrid").jqGrid({
        url: 'http://localhost:56129/Service1.svc/GetDocTemplate',
        datatype: "json",
        colNames: ['DocTemplate Id', 'Ocr Type Id', 'Metadata Type Id', 'Metadata Name', 'Attribute Id', 'Attribute Name', 'Line Number'],
        colModel: [
        {
            name: 'DocTemplateId', index: 'DocTemplateId', editable: true, editoptions: { readonly: 'readonly' }, width: 100, sortable: false, key: true
        },
        {
            name: 'OcrTypeId', index: 'OcrTypeId', editable: true, width: 100, sortable: false, editrules: { required: true }, formoptions: { label: "<span>Ocr Type<span><span style='color:red'>*</span>" }
        },
         {
             name: 'MetadataTypeId', index: 'MetadataTypeId', edittype: 'select', editrules: { required: true }, formoptions: { label: "<span>Metadata Type<span><span style='color:red'>*</span>" }, editoptions: {

                 dataUrl: 'http://localhost:56129/Service1.svc/GetAllMetadataTypes',
                 buildSelect: function (response) {
                     var dataResponse = typeof response === "string" ?
                                 $.parseJSON(response) : response;
                     s = "<select>";
                     s += '<option>' + "Select" + '</option>';
                     jQuery("#Type*").prop("readonly", true);

                     $.each(dataResponse, function () {

                         s += '<option value="' + this.MetadataTypeId + '">' + this.Name +
                                '</option>';
                     })
                     return s + "</select>";

                 },
                 dataEvents: [
                    {
                        type: 'change',
                        fn: function (e) {
                            var result = jQuery("#MetadataTypeId").find(":selected").text();
                            jQuery("#Type*").val(result);

                        }
                    }]

             }, width: 110, editable: true, sortable: false
         },
         {
             name: 'Name', index: 'Name', editable: true, editoptions: { readonly: 'readonly' }, width: 150, sortable: false
         },
         {
             name: 'AttributeId', index: 'AttributeId', width: 100, editable: true, sortable: false, formoptions: { label: "<span>Attribute Id<span><span style='color:red'>*</span>" }, edittype: 'select',
             editoptions: {

                 dataUrl: 'http://localhost:56129/Service1.svc/GetAttributes/1',

                 buildSelect: function (res) {

                     s = "<select>";
                     s += '<option>' + "Select" + '</option>';
                     jQuery("#Type*").prop("readonly", true);

                     //$.each(dataResponse, function () {

                     //    s += '<option value="' + this.AttributeId + '">' + this.AttributeName +
                     //           '</option>';
                     //})
                     return s + "</select>";

                 },
                 dataEvents: [
                    {
                        type: 'change',
                        fn: function (e) {
                            var result = jQuery("#AttributeId").find(":selected").text();
                            jQuery("#Type*").val(result);

                        }
                    }]

             },
         },
         {
             name: 'AttributeName', index: 'AttributeName', editable: true, editoptions: { readonly: 'readonly' }, width: 150, sortable: false
         },

         {
             name: 'LineNo', index: 'LineNo', width: 100, editable: true, sortable: false, editrules: { required: true }, formoptions: { label: "<span>Line Number<span><span style='color:red'>*</span>" }
         },

        ],
        rowNum: 10,
        sorttype: 'number',
        sortname: 'id',
        viewrecords: true,
        sortorder: "desc",
        caption: "Document Template Details",
        pager: '#pager',
        loadonce: true,
        width: 800,
    }).navGrid("#pager",
   { edit: true, add: true, del: true },
     {
         url: '/Default.aspx', editCaption: 'Update DocTemplate Details', closeAfterEdit: true, onclickSubmit: processEditDocTemplate, reloadAfterSubmit: true, beforeShowForm: function (form) { jQuery('#tr_DocTemplateId').hide(); jQuery('#tr_OcrTypeId').hide(); jQuery('#tr_MetadataTypeId').hide(); jQuery('#tr_AttributeId').hide(); jQuery('#tr_Name').hide(), jQuery('#tr_AttributeName').hide() }
     },
    {
        url: '/Default.aspx', editCaption: 'Add New DocTemplate', closeAfterAdd: true, onclickSubmit: processAddDocTemplate, reloadAfterSubmit: true, closeAfterEdit: true,
        beforeShowForm: function (form) {
            jQuery('#tr_DocTemplateId').hide(), jQuery('#tr_Name').hide(), jQuery('#tr_AttributeName').hide();
            jQuery("#tr_MetadataTypeId").find("select").change(function () {
                Test(jQuery("#tr_AttributeId").find("select"));
            })



        }
    },
    { url: '/Default.aspx', editCaption: 'Delete DocTemplate', onclickSubmit: processDeleteDocTemplate, reloadAfterSubmit: true, closeAfterEdit: true }
      );
}


function Test(objAttributeDropdown) {
    objAttributeDropdown.empty();
    var option = '<option>' + "Select" + '</option>';
    jQuery.ajax({
        url: 'http://localhost:56129/Service1.svc/GetAttributes/' + jQuery("#MetadataTypeId").val(),

        contentType: "application/json; charset=utf-8",
        success: function (dataResponse, y) {
            $.each(dataResponse, function () {

                option += '<option value="' + this.AttributeId + '">' + this.AttributeName +
                       '</option>';

            })
            objAttributeDropdown.append(option);
        },
        error: function (xhr, textStatus, errorThrown) {
            alert('An error occurred! ' + errorThrown);
        },
    });

}



function processAddDocTemplate(currentObject, formData) {
    jQuery.ajax({
        url: 'http://localhost:56129/Service1.svc/AddDocTemplate',

        data: JSON.stringify({ OcrTypeId: formData.OcrTypeId, MetadataTypeId: formData.MetadataTypeId, AttributeId: formData.AttributeId, LineNo: formData.LineNo }),
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data, y) {
            alert("Successfully Added to Database!");
            $("#tableJqGrid").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
        },
        error: function (xhr, textStatus, errorThrown) {
            alert('An error occurred! ' + errorThrown);
        },
    });

}

function processEditDocTemplate(currentObject, formData) {
    jQuery.ajax({
        url: 'http://localhost:56129/Service1.svc/EditDocTemplate',
        data: JSON.stringify({ DocTemplateId: formData.DocTemplateId, OcrTypeId: formData.OcrTypeId, MetadataTypeId: formData.MetadataTypeId, AttributeId: formData.AttributeId, LineNo: formData.LineNo }),
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data, y) {
            alert("Selected row edited successfully!");
            $("#tableJqGrid").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
        },
        error: function (xhr, textStatus, errorThrown) {
            alert('An error occurred! ' + errorThrown);
        },
    });

}

function processDeleteDocTemplate(currentObject, formData) {
    jQuery.ajax({
        url: 'http://localhost:56129/Service1.svc/DeleteDocTemplate',

        data: JSON.stringify({
            DocTemplateId: formData
        }),
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data, y) {
            alert("Successfully Deleted");
            $("#tableJqGrid").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
        },
    });
}
/**************************************************************************************************************************************/
//To get mail Search details and load them to the grid
function GetMailSearch() {
    jQuery("#dllTable2").hide();
    jQuery("#tableJqGrid").jqGrid({
        url: 'http://localhost:56129/Service1.svc/GetAllMailSearch',
        datatype: "json",
        colNames: ['MailSearchId', 'Subject'],
        colModel: [
        {
            name: 'MailSearchId', index: 'MailSearchId', editable: true, editoptions: { readonly: 'readonly' }, width: 100, sortable: false, key: true
        },
        {
            name: 'Subject', index: 'Subject', editable: true, width: 150, editrules: { required: true }, sortable: false, formoptions: { label: "<span>Subject<span><span style='color:red'>*</span>" }
        }
        ],
        rowNum: 10,
        sorttype: 'number',
        sortname: 'id',
        viewrecords: true,
        sortorder: "desc",
        caption: " Mail Search Details",
        pager: '#pager',
        loadonce: true,
        width: 800,
    }).navGrid("#pager",
   { edit: false, add: true, del: true },
   {
       url: '/Default.aspx', editCaption: 'Edit Mail Search Record', onclickSubmit: processEditMailSearch, closeAfterAdd: true, reloadAfterSubmit: true, closeAfterEdit: true
   },
    {
        url: '/Default.aspx', editCaption: 'Add New Mail Search Record', onclickSubmit: processAddMailSearch, reloadAfterSubmit: true, closeAfterAdd: true, beforeShowForm: function (form) { jQuery('#tr_MailSearchId').hide() }
    },
    {
        url: '/Default.aspx', editCaption: 'Delete Mail Search Record', onclickSubmit: processDeleteMailSearch, reloadAfterSubmit: true, closeAfterEdit: true
    }
      );
}

function processEditMailSearch(currentObject, formData) {
    jQuery.ajax({
    });
}


//To add new Mail Search record to the grid
function processAddMailSearch(currentObject, formData) {
    jQuery.ajax({
        url: 'http://localhost:56129/Service1.svc/AddMailSearch',

        data: JSON.stringify({ Subject: formData.Subject }),
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data, y) {
            alert("Successfully Added to Database!");
            $("#tableJqGrid").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
        },
        error: function (xhr, textStatus, errorThrown) {
            alert('An error occurred! ' + errorThrown);
        },
    });
}
//To delete  Mail Search values based on row selection
function processDeleteMailSearch(currentObject, formData) {
    jQuery.ajax({
        url: 'http://localhost:56129/Service1.svc/DeleteMailSearch',

        data: JSON.stringify({ MailSearchId: formData }),
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data, y) {
            alert("Successfully Deleted!");
        },
        error: function (xhr, textStatus, errorThrown) {
            alert('An error occurred! ' + errorThrown);
        },
    });
}
/**************************************************************************************************************************************/
//Function to GetMetadata values from metadata table
//load that values into grid
function GetMetadata() {
    jQuery("#dllTable2").hide();
    jQuery("#contentPageMainPage").show();
    jQuery("#tableJqGrid").jqGrid({

        url: 'http://localhost:56129/Service1.svc/GetMetaData',
        datatype: "json",
        colNames: ['MetadataId', 'MetadataTypeId', 'Format', 'Type', 'Keyword'],
        colModel: [
        {
            name: 'MetadataId', index: 'MetadataId', editable: true, editoptions: { readonly: 'readonly' }, width: 150, sortable: false, key: true
        },
        {
            name: 'MetadataTypeId', index: 'MetadataTypeId', edittype: 'select', editrules: { required: true }, formoptions: { label: "<span>MetadataTypeId<span><span style='color:red'>*</span>" }, editoptions: {

                dataUrl: 'http://localhost:56129/Service1.svc/GetNewMetadata',
                buildSelect: function (response) {
                    var dataResponse = typeof response === "string" ?
                                $.parseJSON(response) : response;
                    s = "<select>";
                    s += '<option>' + "Select" + '</option>';
                    jQuery("#Type*").prop("readonly", true);

                    $.each(dataResponse, function () {

                        s += '<option value="' + this.MetadataTypeId + '">' + this.Name +
                               '</option>';
                    })
                    return s + "</select>";

                },
                dataEvents: [
                   {
                       type: 'change',
                       fn: function (e) {
                           var result = jQuery("#MetadataTypeId").find(":selected").text();
                           jQuery("#Type*").val(result);

                       }
                   }]

            }, width: 150, editable: true, sortable: false
        },
        {
            name: 'Format', index: 'Format', editable: true, width: 100, sortable: false, editrules: { required: true }, formoptions: { label: "<span>Format<span><span style='color:red'>*</span>" }
        },
        {
            name: 'Type', index: 'Type', editable: true, width: 100, sortable: false, editrules: { required: true }, formoptions: { label: "<span>Type<span><span style='color:red'>*</span>" }
        },
        {
            name: 'Keyword', index: 'Keyword', editable: true, width: 100, sortable: false, editrules: { required: true }, formoptions: { label: "<span>Keyword<span><span style='color:red'>*</span>" }
        }
        ],
        rowNum: 10,
        sortname: 'id',
        viewrecords: true,
        sortorder: "desc",
        caption: "Metadata Details",
        pager: '#pager',
        width: 800,

    }).navGrid("#pager",
         { edit: true, add: true, del: false },

          {
              url: '/Default.aspx', editCaption: 'Update Meta data', onclickSubmit: processEdit, closeAfterEdit: true, reloadAfterSubmit: true, beforeShowForm: function (form) {
                  jQuery('#tr_MetadataId').hide(); jQuery('#tr_MetadataTypeId').hide();
                  var selRowId = jQuery("#tableJqGrid").jqGrid("getGridParam", "selrow");
                  var rowData = jQuery("#tableJqGrid").jqGrid("getRowData", selRowId);
                  _MetaDataTypeId = rowData.MetadataTypeId;
              }
          },

          { url: '/Default.aspx', editCaption: 'Add Meta data', closeAfterAdd: true, onclickSubmit: processAdd, beforeShowForm: function (form) { jQuery('#tr_MetadataId').hide() } },
          { url: '/Default.aspx', editCaption: 'Delete Meta data', onclickSubmit: processDelete },
        {
            url: "http://localhost:56129/Service1.svc/EditMetaData/"
        }

           );
}

//Function to GetMetadataType values from metadatatype table
//load that values into grid

function GetMetadataType() {
    jQuery("#dllTable2").hide();
    jQuery("#tableJqGrid").jqGrid({
        url: 'http://localhost:56129/Service1.svc/GetAllMetadataTypes',
        datatype: "json",
        colNames: ['MetadataTypeId', 'Name'],
        colModel: [
        {
            name: 'MetadataTypeId', index: 'MetadataTypeId', editable: true, editoptions: { readonly: 'readonly' }, width: 150, sortable: false, key: true
        },
        {
            name: 'Name', index: 'Name', editable: true, width: 150, sortable: false, editrules: { required: true }, formoptions: { label: "<span>Name<span><span style='color:red'>*</span>" }
        }
        ],
        rowNum: 10,

        sortname: 'Name',
        viewrecords: true,
        sortorder: "desc",
        caption: "MetadataType Details",
        pager: '#pager',
        height: "auto",
        width: 800,
        loadonce: true,


    }).navGrid("#pager",
        { edit: true, add: true, del: false, refresh: true },

          { url: '/Default.aspx', editCaption: 'Update Meta data Type', reloadAfterSubmit: true, closeAfterEdit: true, onclickSubmit: processEditMetadataType, beforeShowForm: function (form) { jQuery('#tr_MetadataTypeId').hide() } },

{ url: '/Default.aspx', editCaption: 'Add Meta data Type', reloadAfterSubmit: true, closeAfterAdd: true, onclickSubmit: processAddMetadataType, beforeShowForm: function (form) { jQuery('#tr_MetadataTypeId').hide() } },
{ url: '/Default.aspx', editCaption: 'Delete Meta data Type', reloadAfterSubmit: true, onclickSubmit: processDeleteMetadataType }

           );
}

//function calls on add button press
function processAdd(currentObject, formData) {
    jQuery.ajax({
        url: 'http://localhost:56129/Service1.svc/AddMetadata',

        data: JSON.stringify({ MetadataTypeId: formData.MetadataTypeId, Format: formData.Format, Type: formData.Type, Keyword: formData.Keyword }),
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data, y) {
            alert("Successfully Added to Db");
            $("#tableJqGrid").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
        },
    });

}

//function calls on edit button press
function processEdit(currentObject, formData) {
    jQuery.ajax({
        url: 'http://localhost:56129/Service1.svc/EditMetaData/',
        data: JSON.stringify({ MetadataId: formData.MetadataId, MetadataTypeId: _MetaDataTypeId, Format: formData.Format, Type: formData.Type, Keyword: formData.Keyword }),
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            alert("Successfully edited the selected row");
            $("#tableJqGrid").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
        },
        error: function (data) {
            alert("Successfully edited the selected row 111");
        }
    });

}

function processDelete(currentObject, formData) {
    jQuery.ajax({
        url: 'http://localhost:56129/Service1.svc/DeleteMetadata',

        data: JSON.stringify({
            MetadataId: formData.MetadataId
        }),
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data, y) {
            alert("Successfully Deleted");
            $("#tableJqGrid").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
        },
    });
}

function processAddMetadataType(currentObject, formData) {
    jQuery.ajax({
        url: 'http://localhost:56129/Service1.svc/AddMetadataType',

        data: JSON.stringify({ Name: formData.Name }),
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data, y) {
            $("#tableJqGrid").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
        }


    });

}

function processEditMetadataType(currentObject, formData) {
    jQuery.ajax({

        url: 'http://localhost:56129/Service1.svc/EditMetaDataType',

        data: JSON.stringify({ MetadataTypeId: formData.MetadataTypeId, Name: formData.Name }),
        type: "POST",
        contentType: "application/json; charset=utf-8",

        success: function (data, y) {
            alert("Successfully Edited");
            $("#tableJqGrid").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
        }

    });

}

function processDeleteMetadataType(currentObject, formData) {
    jQuery.ajax({

        url: 'http://localhost:56129/Service1.svc/DeleteMetadatatype',

        data: JSON.stringify({ MetadataTypeId: formData.MetadataTypeId }),
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data, y) {
            alert("Successfully Deleted");
            $("#tableJqGrid").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
        },

    });

}

function GetDataForSelectedCompoment() {

    var selectedValue = jQuery(".test").val();

    switch (selectedValue) {
        case 1:
            DoAjaxCall();
        default:

    }
}


function GetSelectedRowData() {

    var id = jQuery('#tableJqGrid').jqGrid('getGridParam', 'selrow');
    if (id) {
        var ret = jQuery("#tableJqGrid").jqGrid('getRowData', jQuery('#tableJqGrid').jqGrid('getGridParam', 'selrow'));
        return ret;
    } else { alert("Please select row"); }

}

function GetMailSearchCriteria() {
    jQuery("#dllTable2").hide();
    jQuery("#contentPageMainPage").show();
    jQuery("#tableJqGrid").jqGrid({
        url: 'http://localhost:56129/Service1.svc/GetMailSearchCriteria',
        datatype: "json",
        colNames: ['CriteriaId', 'Subject', 'Criteria'],
        colModel: [
        {
            name: 'CriteriaId', index: 'CriteriaId', key: true, editable: true, editoptions: { readonly: true }, width: 150, sortable: false
        },
        {
            name: 'Subject', index: 'Subject', editable: true, edittype: 'select', editoptions: {
                dataUrl: 'http://localhost:56129/Service1.svc/GetAllMailSearch',
                buildSelect: function (response) {
                    var data = typeof response === "string" ?
                                $.parseJSON(response) : response,
                     s = "<select>";
                    $.each(data, function () {
                        s += '<option value="' + this.MailSearchId + '">' + this.Subject +
                           '</option>';
                    })
                    return s + "</select>";
                },
                dataEvents: [
                   {
                       type: 'change',
                       fn: function (e) {
                           var result = jQuery("#MailSearchId").find(":selected").text();
                           jQuery("#Type").val(result);
                           jQuery("#Type").prop("readonly", true);
                       }
                   }]
            }, width: 150, sortable: false
        },
        {
            name: 'Criteria', index: 'Criteria', editable: true, width: 150, sortable: false, formoptions: { label: "<span>Name<span><span style='color:red'>*</span>" }
        }
        ],
        rowNum: 10,
        sortname: 'id',
        viewrecords: true,
        sortorder: "desc",
        caption: "MailSearchCriteria Details",
        pager: '#pager',
        width: 800,
    }).navGrid("#pager",
        { edit: true, add: true, del: true },
         { url: '/Default.aspx', reloadAfterSubmit: true, closeAfterEdit: true, editCaption: 'Update Mail Search Criteria', onclickSubmit: processEditMailSearchCriteria, beforeShowForm: function (form) { jQuery('#tr_CriteriaId').hide() } },
         { url: '/Default.aspx', reloadAfterSubmit: true, closeAfterEdit: true, editCaption: 'Add Mail Search Criteria', onclickSubmit: processAddMailSearchCriteria, beforeShowForm: function (form) { jQuery('#tr_CriteriaId').hide() } },
         { url: '/Default.aspx', reloadAfterSubmit: true, closeAfterEdit: true, editCaption: 'Delete Mail Search Criteria', onclickSubmit: processDeleteMailSearchCriteria }

          );
}

function processAddMailSearchCriteria(currentObject, formData) {
    jQuery.ajax({
        url: 'http://localhost:56129/Service1.svc/AddMailSearchCriteria',

        data: JSON.stringify({ MailSearchId: formData.Subject, Criteria: formData.Criteria }),
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data, y) {
            alert('Successfully Added to Db');
            $("#tableJqGrid").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
        },
    });


}

function processEditMailSearchCriteria(currentObject, formData) {
    jQuery.ajax({

        url: 'http://localhost:56129/Service1.svc/EditMailSearchCriteria',

        data: JSON.stringify({ CriteriaId: formData.CriteriaId, Criteria: formData.Criteria }),
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data, y) {
            alert("Successfully edited the selected row");
            $("#tableJqGrid").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
        },

    });

}

function processDeleteMailSearchCriteria(currentObject, formData) {
    jQuery.ajax({

        url: 'http://localhost:56129/Service1.svc/DeleteMailSearchCriteria',

        data: JSON.stringify({ CriteriaId: formData }),
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data, y) {
            alert("Successfully Deleted");
            $("#tableJqGrid").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
        },

    });

}
//The function makes the metadata type dropdown visible and calls another function to populate the same
function GetAttributesById() {
    jQuery("#dllTable2").show();
    alert("Please select Metadata type");
    jQuery("#dllTable2").on('change', function () { GetAttributesByMetaTypeId(); });
}
//Function to populate metadata type dropdown list
function PopulateMetaTypeDropDown() {
    jQuery.ajax({
        url: 'http://localhost:56129/Service1.svc/GetAllMetadataTypes',
        dataType: "json",
        type: "GET",
        contentType: "application/json; charset=utf-8",
        success: function (response) {
            var data = typeof response === "string" ?
                                $.parseJSON(response) : response;
            var dropDown = jQuery("#dllTable2");
            $.each(data, function () {
                var option = jQuery("<option>");
                option.text(this.Name);
                option.val(this.MetadataTypeId);
                dropDown.append(option);
            })
        },
        dataEvents: [
           {
               type: 'change',
               fn: function (e) {
                   var result = jQuery("#MetadataTypeId").find(":selected").text();
                   jQuery("#Type").val(result);
                   jQuery("#Type").prop("readonly", true);
               }
           }]
    });
    jQuery("#dllTable2").hide();
}
//To display attribute values based on metadata type dropdown selection
function GetAttributesByMetaTypeId() {
    jQuery("#tableJqGrid").jqGrid({
        url: 'http://localhost:56129/Service1.svc/GetAttributes/' + jQuery('#dllTable2').val(),
        datatype: "json",
        colNames: ['AttributeId', 'AttributeName'],
        colModel: [
        {
            name: 'AttributeId', index: 'AttributeId', editable: true, editoptions: { readonly: 'readonly' }, width: 250, sortable: false, key: true
        },
        {
            name: 'AttributeName', index: 'AttributeName', editable: true, width: 250, editrules: { required: true }, sortable: false, editrules: { required: true }, formoptions: { label: "<span>AttributeName<span><span style='color:red'>*</span>" }
        }
        ],
        rowNum: 10,
        sorttype: 'number',
        sortname: 'id',
        viewrecords: true,
        sortorder: "desc",
        caption: "Attribute Details",
        pager: '#pager',
        loadonce: true,
        width: 800,
    }).navGrid("#pager",
   { edit: true, add: true, del: true },
     {
         url: '/Default.aspx', editCaption: 'Update Attribute Details', closeAfterEdit: true, onclickSubmit: processEditAttributes, reloadAfterSubmit: true, beforeShowForm: function (form) { jQuery('#tr_AttributeId').hide() }
     },
    {
        url: '/Default.aspx', editCaption: 'Add New Attribute', closeAfterAdd: true, onclickSubmit: processAddAttributes, reloadAfterSubmit: true, closeAfterEdit: true, beforeShowForm: function (form) { jQuery('#tr_AttributeId').hide() }
    },
    { url: '/Default.aspx', editCaption: 'Delete Attribute', onclickSubmit: processDeleteAttribute, reloadAfterSubmit: true, closeAfterEdit: true }
      );
}
//To edit/update attribute values
function processEditAttributes(currentObject, formData) {
    jQuery.ajax({
        url: 'http://localhost:56129/Service1.svc/EditAttributes',

        data: JSON.stringify({ AttributeId: formData.AttributeId, AttributeName: formData.AttributeName, MetadataTypeId: jQuery('#dllTable2').val() }),
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data, y) {
            alert("Selected row edited successfully!");
            $("#tableJqGrid").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
        },
        error: function (xhr, textStatus, errorThrown) {
            alert('An error occurred! ' + errorThrown);
        },
    });
}
//To add new attributes to the grid
function processAddAttributes(currentObject, formData) {
    jQuery.ajax({
        url: 'http://localhost:56129/Service1.svc/AddAttributes',

        data: JSON.stringify({ AttributeName: formData.AttributeName, MetadataTypeId: jQuery('#dllTable2').val() }),
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data, y) {
            alert("Successfully Added to Database!");
            $("#tableJqGrid").jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
        },
        error: function (xhr, textStatus, errorThrown) {
            alert('An error occurred! ' + errorThrown);
        },
    });
}
//To delete attribute values based on row selection
function processDeleteAttribute(currentObject, formData) {
    jQuery.ajax({
        url: 'http://localhost:56129/Service1.svc/DeleteAttributes',

        data: JSON.stringify({ AttributeId: formData }),
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data, y) {
            alert("Successfully Deleted!");
        },
        error: function (xhr, textStatus, errorThrown) {
            alert('An error occurred! ' + errorThrown);
        },
    });
}
